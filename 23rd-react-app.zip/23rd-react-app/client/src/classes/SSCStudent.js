class SSCStudent{
    constructor(name,engMarks,telMarks,hinMarks,matMarks,sciMarks,socMarks){
        console.log("Inside SSC Marks");
        console.log(name,engMarks,telMarks,hinMarks,matMarks,sciMarks,socMarks);
        this.name = name;
        this.engMarks = engMarks;
        this.telMarks = telMarks;
        this.hinMarks = hinMarks;
        this.matMarks = matMarks;
        this.sciMarks = sciMarks;
        this.socMarks = socMarks;
    }
    calculateResult = ()=>{
        if(this.engMarks >= 35 &&
           this.telMarks >= 35 &&
           this.hinMarks >= 35 &&
           this.matMarks >= 35 &&
           this.sciMarks >= 35 &&
           this.socMarks >= 35 
        ){
            console.log(`${this.name} Passed in Tenth`);

        }else{
            console.log(`${this.name} Failed in Tenth`);

        }

    }
}

export default SSCStudent;