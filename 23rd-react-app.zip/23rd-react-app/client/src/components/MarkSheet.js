import React from 'react'

function MarkSheet(props) {
  return (
    <div>
        
        <div className='flex'>
       
        <h2> Name:{props.name} 
          <br></br>
            english:{props.engMarks} 
            <br></br>
            telugu:{props.telMarks} {" "}
            <br></br>
            hindi:{props.hinMarks} {" "}
            <br></br>
            maths:{props.matMarks} {" "}
            <br></br>
            science:{props.sciMarks} {" "}
            <br></br>
            social:{props.socMarks}
            </h2>
            </div>
            
      
    </div>
  )
}

export default MarkSheet
