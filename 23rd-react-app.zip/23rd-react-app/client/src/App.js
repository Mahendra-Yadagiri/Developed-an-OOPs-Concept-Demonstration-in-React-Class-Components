import './App.css';
import SSCStudent from './classes/SSCStudent';
import MarkSheet from './components/MarkSheet';
 

function App() {
  let Chandra = new SSCStudent("Chandra",72,73,74,75,76,77);
  Chandra.calculateResult();
let sriram = new SSCStudent("sriram",85,45,63,59,48,63);
sriram.calculateResult();
  return (
    <div className="App">
      <h1><u>Oops-Classes</u></h1>
      {/* <h1>Tenth Results</h1> */}
      <h1><u>React code into three clear parts — POP, OOP, and COP</u></h1>
       
       <div className='inline' style={{border:"8px groove black",padding:"10px", background:"linear-gradient( whitesmoke)"}}>
        {/* <MarkSheet "Variables" engMarks="Data types"
      telMarks="Operators" hinMarks="66" matMarks="75" sciMarks="77"
      socMarks="88"></MarkSheet> */}
      <p><b><u>Procedure-Oriented Programming (POP)</u></b></p>
      <p><b>Variables </b></p>
      <p><b>Data types</b></p>
      <p><b>Operators</b></p>
      <p><b>Control Statements</b></p>
      <p><b>Loops</b></p>
      <p><b>Functions</b></p>
      




    


       </div>

       <div className='inline'  style={{border:"8px groove black",padding:"15px", background:"linear-gradient( whitesmoke)"}}>
        {/* <MarkSheet name="Srikanth" engMarks="85"
      telMarks="85" hinMarks="85" matMarks="85" sciMarks="85"
      socMarks="85"></MarkSheet> */}
      <p><b><u>Object-Oriented Programming (OOP)</u></b></p>
      <p><b>Class</b></p>
      <p><b>Encapsulation</b></p>
      <p><b>Inheritance</b></p>
      <p><b>Polymorphism</b></p>
      <p><b>Composition</b></p>
      
      
      </div>
      
      <div className='inline' style={{border:"8px groove black",padding:"10px", background:"linear-gradient( whitesmoke)"}}> 
      {/* <MarkSheet name="Dayakar" engMarks="85"
      telMarks="85" hinMarks="85" matMarks="85" sciMarks="85"
      socMarks="85"></MarkSheet> */}


      <p><b><u>Component-Oriented Programming (COP)</u></b></p>
      <p><b>Components (Functional / Class)</b></p>
      <p><b>Props</b></p>
      <p><b>State</b></p>
      <p><b>Composition</b></p>
      <p><b>Reusability</b></p>

      </div>

      <div style={{display:"block"}}>
        <h1><u>Tenth Results</u></h1>
      <div className='inline' style={{border:"8px groove black",padding:"20px", background:"linear-gradient( whitesmoke)"}}>
      <MarkSheet name="Mahendra" engMarks="85"
      telMarks="87" hinMarks="80" matMarks="67" sciMarks="78"
      socMarks="69"></MarkSheet>
     </div>

     <div className='inline'  style={{border:"8px groove black",padding:"20px", background:"linear-gradient( whitesmoke)"}}>
      <MarkSheet name="Narayana" engMarks="85"
      telMarks="68" hinMarks="89" matMarks="77" sciMarks="75"
      socMarks="55"></MarkSheet>
      </div>

       <div className='inline' style={{border:"8px groove black",padding:"20px", background:"linear-gradient( whitesmoke)"}}>
      <MarkSheet name="Giridhar" engMarks="90"
      telMarks="75" hinMarks="99" matMarks="78" sciMarks="65"
      socMarks="95"></MarkSheet>
      </div>
      </div>

      
    </div>
  );
}

export default App;
